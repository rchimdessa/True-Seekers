import React from 'react';
import Settings from '../Settings';

export default function Notifications() {
	return <Settings />;
}
